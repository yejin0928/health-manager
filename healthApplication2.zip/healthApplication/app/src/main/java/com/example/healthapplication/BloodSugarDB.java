package com.example.healthapplication;

public class BloodSugarDB {
}
