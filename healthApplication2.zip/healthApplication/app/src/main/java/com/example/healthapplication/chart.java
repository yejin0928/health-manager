package com.example.healthapplication;

public class chart {
    PieChart chart1;
    BarChart chart2;

    public void initView(View v){

        chart1 = (PieChart) v.findViewById(R.id.tab1_chart_1);
        chart2 = (BarChart)v.findViewById(R.id.tab1_chart_2);

    }

    // 파이 차트 설정
    private void setPieChart(List<itemModel> itemList) {


        chart1.clearChart();

        chart1.addPieSlice(new PieModel("TYPE 1", 60, Color.parseColor("#CDA67F")));
        chart1.addPieSlice(new PieModel("TYPE 2", 40, Color.parseColor("#00BFFF")));

        chart1.startAnimation();

    }

    // 막대 차트 설정
    private void setBarChart(List<itemModel> itemList2) {

        chart2.clearChart();

        chart2.addBar(new BarModel("12", 10f, 0xFF56B7F1));
        chart2.addBar(new BarModel("13", 10f, 0xFF56B7F1));
        chart2.addBar(new BarModel("14", 10f, 0xFF56B7F1));
        chart2.addBar(new BarModel("15", 20f, 0xFF56B7F1));
        chart2.addBar(new BarModel("16", 10f, 0xFF56B7F1));
        chart2.addBar(new BarModel("17", 10f, 0xFF56B7F1));

        chart2.startAnimation();

    }
}
