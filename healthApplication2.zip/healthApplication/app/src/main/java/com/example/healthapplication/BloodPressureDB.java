package com.example.healthapplication;

public class BloodPressureDB {
}
